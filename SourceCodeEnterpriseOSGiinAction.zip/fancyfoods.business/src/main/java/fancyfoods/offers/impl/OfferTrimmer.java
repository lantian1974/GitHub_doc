package fancyfoods.offers.impl;

import java.util.List;

import fancyfoods.offers.SpecialOffer;

public class OfferTrimmer implements OfferListAdjuster {

	@Override
	public List<SpecialOffer> adjust(List<SpecialOffer> offers) {
		// TODO Auto-generated method stub
		return null;
	}

}

package fancyfoods.offers;

import fancyfoods.food.Food;

public interface SpecialOffer {

    public Food getOfferFood();

    public String getDescription();
}

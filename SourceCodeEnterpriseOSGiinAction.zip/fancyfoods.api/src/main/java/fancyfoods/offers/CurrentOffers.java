package fancyfoods.offers;

import java.util.List;

public interface CurrentOffers {

    public List<SpecialOffer> getCurrentOffers();

}

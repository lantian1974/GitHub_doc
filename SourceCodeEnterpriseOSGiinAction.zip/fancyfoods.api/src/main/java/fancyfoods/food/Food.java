package fancyfoods.food;

public interface Food {

    String getName();

    double getPrice();

    int getQuantityInStock();

}
